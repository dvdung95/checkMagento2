<?php
/**
 * Created by PhpStorm.
 * User: vietdung
 * Date: 26/02/2019
 * Time: 16:08
 */

namespace Vietdung\Staff\Ui\Component\Listing\Columns;

use Magento\Ui\Component\Listing\Columns\Column;


class PageActions extends Column
{
    const CMS_URL_PATH_EDIT = 'staff/index/edit';
    const CMS_URL_PATH_DELETE = 'staff/index/delete';

}